import './index.ts.js';
