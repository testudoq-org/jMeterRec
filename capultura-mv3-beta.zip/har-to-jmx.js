function _(e){return e==="current"?"":e.startsWith("custom:")?e.slice(7):{"chrome-win":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36","chrome-mac":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36","chrome-linux":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36","firefox-win":"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0","firefox-mac":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:121.0) Gecko/20100101 Firefox/121.0","firefox-linux":"Mozilla/5.0 (X11; Linux x86_64; rv:121.0) Gecko/20100101 Firefox/121.0","edge-win":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36 Edg/120.0"}[e]??""}const d={HTTPRequestDefaults:{testClass:"org.apache.jmeter.config.ConfigTestElement",guiClass:"org.apache.jmeter.protocol.http.config.gui.HttpDefaultsGui"},TestPlan:{testClass:"TestPlan",guiClass:"TestPlanGui"},ThreadGroup:{testClass:"ThreadGroup",guiClass:"ThreadGroupGui"},HTTPSamplerProxy:{testClass:"HTTPSamplerProxy",guiClass:"HttpTestSampleGui"}};function z(e,r,t,o="HTTP Request Defaults"){return{type:"HTTPRequestDefaults",testClass:d.HTTPRequestDefaults.testClass,guiClass:d.HTTPRequestDefaults.guiClass,name:o,enabled:!0,domain:e,port:r,protocol:t}}function L(e){const r=new Map;for(const o of e)try{const a=new URL(o.url),s=a.protocol.replace(":",""),u=s==="https"?"443":"80",i=a.port||u,l=`${a.hostname}:${i}`,c=r.get(l);c!==void 0?c.count+=1:r.set(l,{count:1,domain:a.hostname,port:i,protocol:s})}catch{}if(r.size===0)return{primaryDomain:"",primaryPort:"",primaryProtocol:""};let t={count:0,domain:"",port:"",protocol:""};for(const o of r.values())o.count>t.count&&(t=o);return{primaryDomain:t.domain,primaryPort:t.port,primaryProtocol:t.protocol}}function I(e,r="Loop Controller"){return{type:"LoopController",testClass:"LoopController",guiClass:"LoopControlPanel",name:r,enabled:!0,continueForever:!1,loops:e}}function U(e,r="HTTP Cookie Manager"){return{type:"CookieManager",testClass:"CookieManager",guiClass:"CookiePanel",name:r,enabled:!0,eachCookieIsolate:!1,cookies:e.map(t=>({name:t.name,value:t.value,domain:"",path:"",secure:!1}))}}function N(e,r="Status Assertion"){return{type:"ResponseAssertion",testClass:"ResponseAssertion",guiClass:"AssertionGui",name:r,enabled:!0,testField:"Assertion.response_code",testType:8,testStrings:[String(e)],ignoreResponseCode:!1}}function O(e,r="Duration Assertion"){return{type:"DurationAssertion",testClass:"DurationAssertion",guiClass:"DurationAssertionGui",name:r,enabled:!0,durationMs:e}}function X(e=!1,r=500,t="Cache Manager"){return{type:"CacheManager",testClass:"CacheManager",guiClass:"CacheManagerGui",name:t,enabled:!0,clearEachIteration:e,maxNumberOfResults:r}}function W(e,r,t="",o="1",a="JSON Post Processor"){return{type:"json",testClass:"JSONPostProcessor",guiClass:"JSONPostProcessorGui",name:a,enabled:!0,refNames:e,jsonPathExpressions:r,defaultValues:t,matchNumbers:o}}function B(e,r,t="",o="1",a="$1$",s="Regular Expression Extractor"){return{type:"regex",testClass:"RegexExtractor",guiClass:"RegexExtractorGui",name:s,enabled:!0,refname:e,regex:r,template:a,defaultValue:t,matchNumber:o}}function K(e="Untitled Plan"){return{type:"TestPlan",testClass:d.TestPlan.testClass,guiClass:d.TestPlan.guiClass,name:e,enabled:!0,functionalMode:!1,serializeThreadGroups:!1,userDefinedVariables:[]}}function V(e){return{type:"ThreadGroup",testClass:d.ThreadGroup.testClass,guiClass:d.ThreadGroup.guiClass,name:"Thread Group",enabled:!0,onSampleError:"continue",numThreads:e.threads,rampTime:e.rampUp,scheduler:!1,duration:"",delay:"",sameUserOnNextIteration:!0,loopController:I(e.loops)}}function F(e,r,t,o){const a=J(e.url),s=(a==null?void 0:a.hostname)??"",u=(a==null?void 0:a.path)??e.url,i=((a==null?void 0:a.protocol)??"http").replace(":",""),l=(a==null?void 0:a.port)&&a.port.length>0,$=l?a.port:o!==void 0?"":i==="https"?"443":"80",g=`${e.method} ${s}${u} #${r}`,P=e.responseBody??e.body??"",m=o!==void 0&&s===o.domain,b=o!==void 0&&i===o.protocol,y=o!==void 0&&(!l||l&&a.port===o.port);return{type:"HTTPSamplerProxy",testClass:d.HTTPSamplerProxy.testClass,guiClass:d.HTTPSamplerProxy.guiClass,name:g,enabled:!0,domain:m?"":s,port:y?"":$,protocol:b?"":i,path:u,method:e.method,followRedirects:e.followRedirects??!0,useKeepAlive:!0,postBodyRaw:Y(e.method),arguments:Q(e.queryParams,P),headers:Object.entries(t).map(([T,f])=>({name:T,value:f,enabled:!0})),body:P}}function J(e){try{const r=new URL(e);return{host:r.host,hostname:r.hostname,path:r.pathname,protocol:r.protocol.replace(":",""),port:r.port}}catch{return}}function Q(e,r){const t=[{name:"",value:r,alwaysEncode:!1}];for(const[o,a]of Object.entries(e))t.push({name:o,value:a,alwaysEncode:!1});return t}function Y(e){switch(e.toUpperCase()){case"POST":case"PUT":case"PATCH":case"DELETE":return!0;default:return!1}}function Z(e){return`<TestPlan guiclass="${e.guiClass}" testclass="${e.testClass}" testname="${n(e.name)}" enabled="${e.enabled}">
<stringProp name="TestPlan.comments"></stringProp>
<stringProp name="TestPlan.functional_mode">false</stringProp>
<boolProp name="TestPlan.serialize_threadgroups">false</boolProp>
<elementProp name="TestPlan.user_defined_variables" elementType="Arguments" guiclass="ArgumentsPanel" testclass="Arguments" testname="User Defined Variables" enabled="true">
<collectionProp name="Arguments.arguments" />
</elementProp>
</TestPlan>`}function ee(e){const r=e.loopController;return`<ThreadGroup guiclass="${e.guiClass}" testclass="${e.testClass}" testname="${n(e.name)}" enabled="${e.enabled}">
<stringProp name="ThreadGroup.on_sample_error">${e.onSampleError}</stringProp>
<elementProp name="ThreadGroup.main_controller" elementType="LoopController" guiclass="LoopControlPanel" testclass="LoopController" testname="Loop Controller" enabled="true">
<boolProp name="LoopController.continue_forever">${r.continueForever?"true":"false"}</boolProp>
<stringProp name="LoopController.loops">${r.loops}</stringProp>
</elementProp>
<stringProp name="ThreadGroup.num_threads">${e.numThreads}</stringProp>
<stringProp name="ThreadGroup.ramp_time">${e.rampTime}</stringProp>
<boolProp name="ThreadGroup.scheduler">false</boolProp>
<stringProp name="ThreadGroup.duration">${e.duration}</stringProp>
<stringProp name="ThreadGroup.delay"></stringProp>
<boolProp name="ThreadGroup.same_user_on_next_iteration">true</boolProp>
</ThreadGroup>`}function re(e){return`<ConfigTestElement guiclass="org.apache.jmeter.protocol.http.config.gui.HttpDefaultsGui" testclass="org.apache.jmeter.config.ConfigTestElement" testname="${n(e.name)}" enabled="${e.enabled}">
<elementProp name="HTTPsampler.Arguments" elementType="Arguments" guiclass="HTTPArgumentsPanel" testclass="Arguments" testname="User Defined Variables" enabled="true">
<collectionProp name="Arguments.arguments" />
</elementProp>
<stringProp name="HTTPSampler.domain">${n(e.domain)}</stringProp>
<stringProp name="HTTPSampler.port">${n(e.port)}</stringProp>
<stringProp name="HTTPSampler.protocol">${n(e.protocol)}</stringProp>
</ConfigTestElement>`}function te(e){const r=e.arguments.map(o=>`<elementProp name="" elementType="HTTPArgument" guiclass="HTTPArgumentGui" testclass="HTTPArgument" testname="Argument" enabled="true">
<boolProp name="HTTPArgument.always_encode">${o.alwaysEncode?"true":"false"}</boolProp>
<stringProp name="Argument.name">${n(o.name)}</stringProp>
<stringProp name="Argument.value"><![CDATA[${A(o.value)}]]></stringProp>
<stringProp name="Argument.metadata">=</stringProp>
</elementProp>`).join(`
`),t=e.headers.length===0?`<elementProp name="HTTPsampler.Headers" elementType="HeaderManager" guiclass="HeaderPanel" testclass="HeaderManager" testname="HTTP Default Headers" enabled="true">
<collectionProp name="HeaderManager.headers" />
</elementProp>`:`<elementProp name="HTTPsampler.Headers" elementType="HeaderManager" guiclass="HeaderPanel" testclass="HeaderManager" testname="HTTP Default Headers" enabled="true">
<collectionProp name="HeaderManager.headers">
${e.headers.map(o=>`              <elementProp name="" elementType="Header" guiclass="Header" testclass="Header" testname="${n(o.name)}" enabled="true">
<stringProp name="Header.name">${n(o.name)}</stringProp>
<stringProp name="Header.value">${n(o.value)}</stringProp>
<stringProp name="Header.enabled">${o.enabled?"true":"false"}</stringProp>
</elementProp>`).join(`
`)}
</collectionProp>
</elementProp>`;return`<HTTPSamplerProxy guiclass="${e.guiClass}" testclass="${e.testClass}" testname="${n(e.name)}" enabled="${e.enabled}">
<boolProp name="HTTPSampler.postBodyRaw">${e.postBodyRaw?"true":"false"}</boolProp>
<elementProp name="HTTPsampler.Arguments" elementType="Arguments" guiclass="ArgumentsPanel" testclass="Arguments" testname="User Defined Variables" enabled="true">
<collectionProp name="Arguments.arguments">
<elementProp name="" elementType="HTTPArgument" guiclass="HTTPArgumentGui" testclass="HTTPArgument" testname="Argument" enabled="true">
<boolProp name="HTTPArgument.always_encode">false</boolProp>
<stringProp name="Argument.name"></stringProp>
<stringProp name="Argument.value"><![CDATA[${A(e.body)}]]></stringProp>
<stringProp name="Argument.metadata">=</stringProp>
</elementProp>
${r}
</collectionProp>
</elementProp>
 ${e.domain?`            <stringProp name="HTTPSampler.domain">${n(e.domain)}</stringProp>`:""}
 ${e.port?`            <stringProp name="HTTPSampler.port">${n(e.port)}</stringProp>`:""}
 ${e.protocol?`            <stringProp name="HTTPSampler.protocol">${n(e.protocol)}</stringProp>`:""}
<stringProp name="HTTPSampler.path">${n(e.path)}</stringProp>
<stringProp name="HTTPSampler.method">${n(e.method)}</stringProp>
<boolProp name="HTTPSampler.follow_redirects">${e.followRedirects?"true":"false"}</boolProp>
<boolProp name="HTTPSampler.auto_redirects">false</boolProp>
<boolProp name="HTTPSampler.use_keepalive">true</boolProp>
<boolProp name="HTTPSampler.DO_MULTIPART_POST">false</boolProp>
<stringProp name="HTTPSampler.embedded_url_re"></stringProp>
<stringProp name="HTTPSampler.connect_timeout"></stringProp>
<stringProp name="HTTPSampler.response_timeout"></stringProp>
${t}
</HTTPSamplerProxy>`}function oe(e){const r=e.cookies.map(t=>`<elementProp name="" elementType="Cookie" guiclass="HTTPPanel" testclass="Cookie" testname="${n(t.name)}" enabled="true">
<stringProp name="Cookie.domain">${n(t.domain??"")}</stringProp>
<stringProp name="Cookie.path">${n(t.path??"")}</stringProp>
<stringProp name="Cookie.value">${n(t.value)}</stringProp>
<stringProp name="Cookie.secure">${t.secure?"true":"false"}</stringProp>
<boolProp name="Cookie.expires">false</boolProp>
</elementProp>`).join(`
`);return`<${e.type} guiclass="${e.guiClass}" testclass="${e.testClass}" testname="${n(e.name)}" enabled="${e.enabled}">
<collectionProp name="CookieManager.cookies">
${r}
</collectionProp>
<stringProp name="CookieManager.eachCookieIsolate">false</stringProp>
</${e.type}>`}function se(e){return`<${e.type} guiclass="${e.guiClass}" testclass="${e.testClass}" testname="${n(e.name)}" enabled="${e.enabled}">
<collectionProp name="Asserter.urls">
<boolProp name="clear">false</boolProp>
</collectionProp>
<stringProp name="Assertion.test_field">${e.testField}</stringProp>
<stringProp name="Assertion.test_type">${e.testType}</stringProp>
<boolProp name="Assertion.assume_success">false</boolProp>
<stringProp name="Assertion.custom_message"></stringProp>
  <collectionProp name="Assertion.test_values">
  ${e.testStrings.map(r=>`<stringProp name="200">${n(r)}</stringProp>`).join(`
`)}
  </collectionProp>
<collectionProp name="Asserter.test_configs">
<elementProp name="0" elementType="field">
<boolProp name="IncludeEquality">true</boolProp>
<boolProp name="IncludeRegexp">false</boolProp>
<stringProp name="field">${e.testField}</stringProp>
<stringProp name="match">${e.testStrings[0]??""}</stringProp>
<stringProp name="not">false</stringProp>
</elementProp>
</collectionProp>
</${e.type}>`}function ae(e){return`<${e.type} guiclass="${e.guiClass}" testclass="${e.testClass}" testname="${n(e.name)}" enabled="${e.enabled}">
<stringProp name="DurationAssertion.duration">${e.durationMs}</stringProp>
</${e.type}>`}function ne(e){return`<${e.type} guiclass="${e.guiClass}" testclass="${e.testClass}" testname="${n(e.name)}" enabled="${e.enabled}">
<boolProp name="clearEachIteration">${e.clearEachIteration?"true":"false"}</boolProp>
<intProp name="maxNumberOfResults">${e.maxNumberOfResults}</intProp>
</${e.type}>`}function ie(e){return`<${e.type} guiclass="${e.guiClass}" testclass="${e.testClass}" testname="${n(e.name)}" enabled="${e.enabled}">
<stringProp name="${e.type}.referenceNames">${n(e.refNames)}</stringProp>
<stringProp name="${e.type}.jsonPathExpressions">${n(e.jsonPathExpressions)}</stringProp>
<stringProp name="${e.type}.defaultValues">${n(e.defaultValues)}</stringProp>
<stringProp name="${e.type}.match_numbers">${n(e.matchNumbers)}</stringProp>
</${e.type}>`}function le(e){return`<${e.type} guiclass="${e.guiClass}" testclass="${e.testClass}" testname="${n(e.name)}" enabled="${e.enabled}">
<stringProp name="${e.type}.refname">${n(e.refname)}</stringProp>
<stringProp name="${e.type}.regex"><![CDATA[${A(e.regex)}]]></stringProp>
<stringProp name="${e.type}.template">${n(e.template)}</stringProp>
<stringProp name="${e.type}.default">${n(e.defaultValue)}</stringProp>
<stringProp name="${e.type}.match_number">${n(e.matchNumber)}</stringProp>
</${e.type}>`}function n(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function A(e){return e.replaceAll("]]>","]]]]><![CDATA[>")}function ue(e,r,t){const{primaryDomain:o,primaryPort:a,primaryProtocol:s}=L(r),i=o.length>0||a.length>0||s.length>0?{domain:o,port:a,protocol:s}:void 0,l=Z(K(e.name)),c=ee(V(e.threadGroup)),$=re(z(o,a,s)),g=de(r),P=(t==null?void 0:t.recordCookies)!==!1&&g.length>0?oe(U(g)):"",m=(t==null?void 0:t.cacheEnabled)===!0?ne(X()):"",b=r.map((f,h)=>{var x,v;const C=h>0?r[h-1]:void 0,H=C!==void 0?new Date(f.timestamp).getTime()-new Date(C.timestamp).getTime():0,E=H>0?ce(H,t==null?void 0:t.thinkTime):"",k=((x=t==null?void 0:t.assertion)==null?void 0:x.enabled)===!0?se(N(t.assertion.expectStatus)):"",D=((v=t==null?void 0:t.durationAssertion)==null?void 0:v.enabled)===!0?ae(O(t.durationAssertion.thresholdMs)):"",w=((t==null?void 0:t.extractors)??[]).map(p=>p.type==="json"?`${ie(W(p.refNames,p.jsonPathExpressions,p.defaultValues??"",p.matchNumbers??"1"))}<hashTree/>`:p.type==="regex"?`${le(B(p.refname,p.regex,p.defaultValue??"",p.matchNumber??"1",p.template??"$1$"))}<hashTree/>`:"").join(`
`),j=F(f,h,me(f.headers,t),i),G=te(j),M=w.length>0?`
${w}`:"";return`${E}${k}${D}${G}<hashTree/>${M}`}).join(`
`),y=P?`${P}<hashTree/>
`:"",T=m?`${m}<hashTree/>
`:"";return`<?xml version="1.0" encoding="UTF-8"?>
<jmeterTestPlan version="1.2" properties="5.0" jmeter="5.6.3">
<hashTree>
${l}
<hashTree>
${c}
<hashTree>
${$}
<hashTree/>
${T}${y}${b}
</hashTree>
</hashTree>
</hashTree>
</jmeterTestPlan>`}function ce(e,r){if(e<=0||!((r==null?void 0:r.enabled)??!0))return"";const o=r!=null&&r.randomize?Math.round(e*(1-(r.rangePercent??20)/100)):e,a=r!=null&&r.randomize?"UniformRandomTimer":"ConstantTimer",s=r!=null&&r.randomize?"UniformRandomTimerGui":"ConstantTimerGui",u=r!=null&&r.randomize?Math.round(e*(1+(r.rangePercent??20)/100)):o,i=r!=null&&r.randomize?`${o} ${u}`:`${o}`;return`<${a} guiclass="${s}" testclass="${a}" testname="Think Time" enabled="true">
<stringProp name="${a}.delay">${i}</stringProp>
</${a}>
<hashTree/>
`}const pe=new Set(["cookie","cookie2"]);function me(e,r){const t={},o=r==null?void 0:r.userAgent,a=o!==void 0&&o!=="current"?_(o):"";for(const[s,u]of Object.entries(e)){const i=s.toLowerCase();(i==="cookie"||i==="cookie2")&&(r==null?void 0:r.recordCookies)!==!1||(t[s]=u)}return a.length>0?t["User-Agent"]=a:o==="current"&&(delete t["User-Agent"],delete t["user-agent"]),t}function de(e,r=!0){if(!r)return[];const t=new Set,o=[];for(const a of e)for(const[s,u]of Object.entries(a.headers)){const i=s.toLowerCase();if(!pe.has(i))continue;const l=u.trim();if(l.length===0)continue;const c=`${i}:${l}`;t.has(c)||(t.add(c),o.push({name:s,value:l}))}return o}function be(e,r,t){ge(e);const a=e.log.entries.map((s,u)=>{var h,C;const i=fe(s.request.url),l=S(s.request.headers),c=S(s.response.headers),$=Te(s.request.queryString),g=((h=s.request.postData)==null?void 0:h.text)??"",P=s.response.content.text??"",m=he(((C=s.request.postData)==null?void 0:C.mimeType)??s.response.content.mimeType,g),b=(i==null?void 0:i.host)??s.request.url,y=(i==null?void 0:i.path)??s.request.url,T=(i==null?void 0:i.protocol)??"http",f=(i==null?void 0:i.port)??(T==="https"?443:80);return{id:`har-${u}`,sequence:u,request:{method:s.request.method,url:s.request.url,domain:b,path:y,port:f,protocol:T,headers:l,queryString:$,body:g||void 0,bodyType:m},response:{status:s.response.status,statusText:s.response.statusText,headers:c,body:P||void 0,size:s.response.bodySize},timing:{startTime:s.startedDateTime,duration:s.time,thinkTime:0},metadata:{isJsonRequest:m==="json",isFormRequest:m==="form",hasAuth:R(l)||R(c),authType:$e(l)}}}).map(s=>({id:s.id,timestamp:s.timing.startTime,method:s.request.method,url:s.request.url,path:s.request.path,headers:s.request.headers,queryParams:s.request.queryString,body:s.request.body,contentType:s.request.bodyType==="json"?"application/json":void 0,statusCode:s.response.status,responseHeaders:s.response.headers,responseBody:s.response.body,responseBodyContentType:s.response.headers["content-type"]??s.response.headers["Content-Type"],responseBodySize:s.response.size}));return ue(r,a,t)}function ge(e){if(!(e!=null&&e.log))throw new Error("Invalid HAR: missing log object");if(typeof e.log!="object"||e.log===null)throw new Error("Invalid HAR: log must be an object");if(e.log.version!=="1.2")throw new Error(`Unsupported HAR version: ${e.log.version}`);if(!Array.isArray(e.log.entries))throw new Error("Invalid HAR: log.entries must be an array");if(e.log.entries.length===0)throw new Error("Invalid HAR: no entries found");Pe(e.log.entries)}function Pe(e){for(let r=0;r<e.length;r++){const t=e[r];if(typeof t!="object"||t===null)throw new Error(`Invalid HAR entry at index ${r}: entry must be an object`);if(typeof t.startedDateTime!="string")throw new Error(`Invalid HAR entry at index ${r}: missing startedDateTime`);if(typeof t.request!="object"||t.request===null)throw new Error(`Invalid HAR entry at index ${r}: missing request object`);const o=t.request;if(typeof o.method!="string")throw new Error(`Invalid HAR entry at index ${r}: missing request.method`);if(typeof o.url!="string")throw new Error(`Invalid HAR entry at index ${r}: missing request.url`);if(!Array.isArray(o.headers))throw new Error(`Invalid HAR entry at index ${r}: request.headers must be an array`);if(!Array.isArray(o.queryString))throw new Error(`Invalid HAR entry at index ${r}: request.queryString must be an array`);if(typeof t.response!="object"||t.response===null)throw new Error(`Invalid HAR entry at index ${r}: missing response object`);const a=t.response;if(typeof a.status!="number")throw new Error(`Invalid HAR entry at index ${r}: missing response.status`);if(typeof a.headers!="object"||a.headers===null)throw new Error(`Invalid HAR entry at index ${r}: response.headers must be an object`);if(!Array.isArray(a.headers))throw new Error(`Invalid HAR entry at index ${r}: response.headers must be an array`);if(typeof a.content!="object"||a.content===null)throw new Error(`Invalid HAR entry at index ${r}: missing response.content`);if(typeof t.timings!="object"||t.timings===null)throw new Error(`Invalid HAR entry at index ${r}: missing timings`)}}function ye(e){const r=new Set;for(const t of e.log.entries)try{const a=new URL(t.request.url).hostname.toLowerCase().trim();a.length>0&&r.add(a)}catch{}return[...r].sort((t,o)=>t.localeCompare(o))}function fe(e){try{const r=new URL(e),t=r.protocol.replace(":",""),o=r.port?Number(r.port):t==="https"?443:80;return{protocol:t,host:r.host,path:r.pathname+r.search,port:o}}catch{return null}}function S(e){const r={};for(const t of e)r[t.name.toLowerCase()]=t.value;return r}function Te(e){const r={};for(const t of e)r[t.name]=t.value;return r}function he(e,r){const t=e.toLowerCase();return t.includes("json")||t.includes("javascript")?"json":t.includes("form")||t.includes("x-www-form-urlencoded")?"form":t.includes("xml")?"xml":r.trim().length===0||t.includes("text")?"text":"binary"}function R(e){const r=Object.keys(e).map(t=>t.toLowerCase());return r.includes("authorization")||r.includes("x-api-key")||r.includes("x-auth-token")}function $e(e){const r=e.authorization??e.Authorization;if(r)return r.startsWith("Basic ")?"basic":r.startsWith("Bearer ")?"bearer":"cookie"}export{be as c,ye as e,ge as v};
